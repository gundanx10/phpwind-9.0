<?php
Wind::import('APPS:u.service.helper.PwUserHelper');

/**
 * 左边导航和资料tab扩展
 *
 * @author xiaoxia.xu <xiaoxia.xuxx@aliyun-inc.com>
 * @copyright ?2003-2103 phpwind.com
 * @license http://www.phpwind.com
 * @version $Id: BaseProfileController.php 22678 2012-12-26 09:22:23Z jieyin $
 * @package src.products.u.controller.profile
 */
class BaseProfileController extends PwBaseController {
	
	protected $defaultGroups = array(
			0 => array('name' => '普通组', 'gid' => '0'), 
		);
	protected $bread = array();
	/* (non-PHPdoc)
	 * @see PwBaseController::beforeAction()
	 */
	public function beforeAction($handlerAdapter) {
		parent::beforeAction($handlerAdapter);
		if (!$this->loginUser->isExists()) {
			$this->forwardRedirect(WindUrlHelper::createUrl('3g/login/run'));
		}
	}
	
}