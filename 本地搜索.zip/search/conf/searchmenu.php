<?php

return array(
	'appcenter_app_search' => array('搜索设置', 'app_search/manage/*', '', '', 'appcenter'),
);